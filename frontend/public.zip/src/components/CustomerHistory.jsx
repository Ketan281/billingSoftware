import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from '@mui/material';
import { useParams } from 'react-router-dom';

const CustomerHistory = () => {
  const { id } = useParams(); // Assume `id` is passed as a route parameter
  const [history, setHistory] = useState([]);
  console.log(id,"idddd")
  useEffect(() => {
    const fetchHistory = async () => {
        try {
          const response = await axios.get(`http://localhost:5000/customers/${id}/history`);
          console.log('API Response:', response.data);
          setHistory(response.data);
        } catch (error) {
          console.error('Error fetching customer history:', error);
        }
      };
      

    fetchHistory();
  }, [id]);

  if (!history.customer || history.history?.length === 0) {
    return (
      <Box p={3} textAlign="center">
        <Typography>No history found for this customer.</Typography>
      </Box>
    );
  }
  

  return (
    <Box p={3} maxWidth="1200px" mx="auto">
      <Typography variant="h4" gutterBottom>
        History for {history[0]?.name}
      </Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Date</TableCell>
              <TableCell>Quantity</TableCell>
              <TableCell>Weight</TableCell>
              <TableCell>Rate</TableCell>
              <TableCell>Payment</TableCell>
              <TableCell>Due Payment</TableCell>
              <TableCell>Total Payment</TableCell>
              <TableCell>Credit Payment</TableCell>
              <TableCell>Total Due Payment</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {history.map((entry, index) => (
              <TableRow key={index}>
                <TableCell>{entry.date}</TableCell>
                <TableCell>{entry.quantity}</TableCell>
                <TableCell>{entry.weight}</TableCell>
                <TableCell>{entry.rate}</TableCell>
                <TableCell>{entry.payment}</TableCell>
                <TableCell>{entry.duePayment}</TableCell>
                <TableCell>{entry.totalPayment}</TableCell>
                <TableCell>{entry.creditPayment}</TableCell>
                <TableCell>{entry.totalDuePayment}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default CustomerHistory;
