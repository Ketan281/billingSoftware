import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  Divider,
  Button,
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const DetailedBill = () => {
  const { date } = useParams();
  const [detailedBill, setDetailedBill] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDetailedBill = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/bills/${date}`);
        setDetailedBill(response.data);
      } catch (error) {
        console.error('Error fetching detailed bill:', error);
      }
    };
    fetchDetailedBill();
  }, [date]);

  if (detailedBill.length === 0) {
    return (
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h6">No Bill Found</Typography>
      </Box>
    );
  }

  const bill = detailedBill[0];
  const rows = Array.isArray(bill.rows) ? bill.rows : JSON.parse(bill.rows);
  const totals = typeof bill.totals === 'object' ? bill.totals : JSON.parse(bill.totals);

  return (
    <Box sx={{ p: 3, maxWidth: '1200px', mx: 'auto' }}>
      {/* Header */}
      <Typography variant="h4" textAlign="center" gutterBottom>
        Detailed Bill - {date}
      </Typography>
      <Divider sx={{ mb: 3 }} />
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Box>
          <Typography variant="body1">
            <strong>Lifting Rate:</strong> {bill.liftingRate}
          </Typography>
          <Typography variant="body1">
            <strong>Lifting Company:</strong> {bill.liftingCompanyName}
          </Typography>
        </Box>
        <Box>
          <Typography variant="body1">
            <strong>Driver Name:</strong> {bill.driverName}
          </Typography>
          <Typography variant="body1">
            <strong>Cleaner Name:</strong> {bill.cleanerName}
          </Typography>
        </Box>
      </Box>

      {/* Rows Table */}
      <TableContainer component={Paper} sx={{ mb: 4 }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Customer Name</TableCell>
              <TableCell>Quantity</TableCell>
              <TableCell>Weight</TableCell>
              <TableCell>Rate</TableCell>
              <TableCell>Payment</TableCell>
              <TableCell>Due Payment</TableCell>
              <TableCell>Total Payment</TableCell>
              <TableCell>Credit Payment</TableCell>
              <TableCell>Total Due Payment</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row, index) => (
              <TableRow key={index}>
                <TableCell>{row.customerName}</TableCell>
                <TableCell>{row.quantity}</TableCell>
                <TableCell>{row.weight}</TableCell>
                <TableCell>{row.rate}</TableCell>
                <TableCell>{row.payment}</TableCell>
                <TableCell>{row.duePayment}</TableCell>
                <TableCell>{row.totalPayment}</TableCell>
                <TableCell>{row.creditPayment}</TableCell>
                <TableCell>{row.totalDuePayment}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Totals Section */}
      <Box>
        <Typography variant="h5" gutterBottom>
          Summary
        </Typography>
        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Typography variant="body1">
            <strong>Total Quantity:</strong> {totals.quantity}
          </Typography>
          <Typography variant="body1">
            <strong>Total Weight:</strong> {totals.weight}
          </Typography>
          <Typography variant="body1">
            <strong>Total Payment:</strong> {totals.payment}
          </Typography>
          <Typography variant="body1">
            <strong>Total Due Payment:</strong> {totals.duePayment}
          </Typography>
          <Typography variant="body1">
            <strong>Total Credit Payment:</strong> {totals.creditPayment}
          </Typography>
          <Typography variant="body1">
            <strong>Total Outstanding Due:</strong> {totals.totalDuePayment}
          </Typography>
        </Box>
      </Box>
      <Button
        variant="contained"
        sx={{ mt: 3 }}
        onClick={() => navigate('/all-bills')}
      >
        Back to All Bills
      </Button>
    </Box>
  );
};

export default DetailedBill;
