import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemText,
  Card,
  CardContent,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const AllBills = () => {
  const [bills, setBills] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBills = async () => {
      try {
        const response = await axios.get('http://localhost:5000/bills');
        setBills(response.data);
      } catch (error) {
        console.error('Error fetching bills:', error);
      }
    };
    fetchBills();
  }, []);

  return (
    <Box p={2}>
      <Typography variant="h5" gutterBottom>
        All Bills
      </Typography>
      <List>
        {bills.map((bill) => (
          <ListItem
            key={bill.id}
            button
            onClick={() => navigate(`/bill/${bill.date}`)}
            sx={{ '&:hover': { backgroundColor: '#f0f0f0' } }}
          >
            <ListItemText primary={`Bill Date: ${bill.date}`} />
          </ListItem>
        ))}
      </List>
    </Box>
  );
};

export default AllBills;
