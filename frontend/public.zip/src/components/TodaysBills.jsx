import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableFooter,
  TextField,
  Button,
  Paper,
  IconButton,
  Grid,
} from "@mui/material";
import CheckIcon from "@mui/icons-material/Check";
import Autocomplete from "@mui/material/Autocomplete";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";

const TodaysBills = () => {
  const [rows, setRows] = useState([]);
  const [customerSuggestions, setCustomerSuggestions] = useState([]);
  const [customerDuePayments, setCustomerDuePayments] = useState({});
  const [liftingRate, setLiftingRate] = useState("");
  const [liftingCompanyName, setLiftingCompanyName] = useState("");
  const [driverName, setDriverName] = useState("");
  const [cleanerName, setCleanerName] = useState("");

  const getFormattedDate = () => {
    const today = new Date();
    return today.toLocaleDateString("en-GB").split("/").reverse().join("-");
  };

  useEffect(() => {
    const fetchDuePayments = async () => {
      try {
        const response = await axios.get("http://localhost:5000/customers");
        const data = response.data;
        const duePayments = {};
        data.forEach((customer) => {
          duePayments[customer.name] = customer.duePayment || 0;
        });
        setCustomerDuePayments(duePayments);
      } catch (error) {
        console.error("Error fetching customer due payments:", error);
      }
    };
    fetchDuePayments();
  }, []);
  const saveBill = async () => {
    const payload = {
      date: getFormattedDate(),
      liftingRate,
      liftingCompanyName,
      driverName,
      cleanerName,
      rows,
      totals: {
        quantity: calculateTotal("quantity"),
        weight: calculateTotal("weight"),
        payment: calculateTotal("payment"),
        duePayment: calculateTotal("duePayment"),
        totalPayment: calculateTotal("totalPayment"),
        creditPayment: calculateTotal("creditPayment"),
        totalDuePayment: calculateTotal("totalDuePayment"),
      },
    };

    try {
      await axios.post("http://localhost:5000/bills", payload);
      toast.success("Bill and customer history saved successfully!");
    } catch (error) {
      console.error("Error saving bill and customer history:", error);
      toast.error("Failed to save bill.");
    }
  };

  const addRow = () => {
    setRows([
      ...rows,
      {
        customerName: "",
        quantity: "",
        weight: "",
        rate: "",
        payment: 0,
        duePayment: 0,
        totalPayment: 0,
        creditPayment: "",
        totalDuePayment: 0,
      },
    ]);
  };

  const handleInputChange = (index, field, value) => {
    const updatedRows = rows.map((row, i) => {
      if (i === index) {
        const updatedRow = { ...row, [field]: value };
        if (field === "customerName") {
          updatedRow.duePayment = customerDuePayments[value] || 0;
        }
        if (field === "weight" || field === "rate") {
          updatedRow.payment =
            (parseFloat(updatedRow.weight) || 0) *
            (parseFloat(updatedRow.rate) || 0);
        }
        updatedRow.totalPayment =
          (updatedRow.payment || 0) + (updatedRow.duePayment || 0);
        updatedRow.totalDuePayment =
          (updatedRow.totalPayment || 0) -
          (parseFloat(updatedRow.creditPayment) || 0);
        return updatedRow;
      }
      return row;
    });
    setRows(updatedRows);
  };

  const fetchCustomerSuggestions = async (query) => {
    try {
      const response = await axios.get(
        `http://localhost:5000/customers/search?query=${query}`
      );
      setCustomerSuggestions(response.data || []);
    } catch (error) {
      console.error("Error fetching customer suggestions:", error);
    }
  };

  const updateTotalDuePayment = async (name, totalDuePayment, row) => {
    try {
      await axios.post(`http://localhost:5000/customers/${name}/save-entry`, {
        date: getFormattedDate(),
        ...row,
      });

      await axios.post("http://localhost:5000/customers/update-due", {
        name,
        duePayment: totalDuePayment,
      });

      setCustomerDuePayments((prev) => ({
        ...prev,
        [name]: totalDuePayment,
      }));

      toast.success(`Entry saved and due payment updated for ${name}`);
    } catch (error) {
      console.error("Error saving entry or updating due payment:", error);
      toast.error("Failed to save entry or update due payment.");
    }
  };

  const calculateTotal = (field) =>
    rows.reduce((sum, row) => sum + (parseFloat(row[field]) || 0), 0);

  const inputFieldStyle = {
    width: "60%", // Adjusted to 60% of current width
  };

  return (
    <Box p={1} sx={{ width: "100%" }}>
      <Typography variant="h5" gutterBottom textAlign={"center"}>
        Momin Chicken Suppliers
      </Typography>

      {/* Table Header Controls */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        {/* Left Section: Date and Lifting Rate */}
        <Box>
          <Button
            variant="contained"
            color="primary"
            onClick={addRow}
            sx={{
              backgroundColor: "#1976d2",
              color: "#fff",
              mb: 3,
              "&:hover": {
                backgroundColor: "#1565c0",
              },
            }}
          >
            Add Entry
          </Button>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>
            Date
          </Typography>
          <Typography
            variant="h6"
            sx={{
              border: "1px solid #ccc",
              padding: "6px",
              borderRadius: "4px",
            }}
          >
            {getFormattedDate()}
          </Typography>
          <TextField
            label="Lifting Rate"
            type="number"
            value={liftingRate}
            onChange={(e) => setLiftingRate(e.target.value)}
            fullWidth
            InputProps={{
              inputProps: { style: { appearance: "textfield" } },
            }}
            sx={{
              ...inputFieldStyle,
              mt: 2,
              "& input[type=number]::-webkit-inner-spin-button": {
                display: "none",
              },
              "& input[type=number]::-webkit-outer-spin-button": {
                display: "none",
              },
            }}
          />
        </Box>

        {/* Right Section: Lifting Company, Driver Name, Cleaner Name */}
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 2,
            width: "50%",
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Typography variant="subtitle2" sx={{ flex: 1, pr: 1 }}>
              Lifting Company
            </Typography>
            <TextField
              value={liftingCompanyName}
              onChange={(e) => setLiftingCompanyName(e.target.value)}
              fullWidth
              sx={inputFieldStyle}
            />
          </Box>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Typography variant="subtitle2" sx={{ flex: 1, pr: 1 }}>
              Driver Name
            </Typography>
            <TextField
              value={driverName}
              onChange={(e) => setDriverName(e.target.value)}
              fullWidth
              sx={inputFieldStyle}
            />
          </Box>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Typography variant="subtitle2" sx={{ flex: 1, pr: 1 }}>
              Cleaner Name
            </Typography>
            <TextField
              value={cleanerName}
              onChange={(e) => setCleanerName(e.target.value)}
              fullWidth
              sx={inputFieldStyle}
            />
          </Box>
        </Box>
      </Box>

      {/* Table */}
      <TableContainer
        component={Paper}
        sx={{ width: "100%", margin: "0 auto" }}
      >
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Customer Name</TableCell>
              <TableCell>Quantity</TableCell>
              <TableCell>Weight</TableCell>
              <TableCell>Rate</TableCell>
              <TableCell>Payment</TableCell>
              <TableCell>Due Payment</TableCell>
              <TableCell>Total Payment</TableCell>
              <TableCell>Credit Payment</TableCell>
              <TableCell>Total Due Payment</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row, index) => (
              <TableRow key={index}>
                <TableCell>
                  <Autocomplete
                    freeSolo
                    options={customerSuggestions.map((option) => option.name)}
                    onInputChange={(event, value) => {
                      if (value) {
                        fetchCustomerSuggestions(value);
                      }
                    }}
                    onChange={(event, value) => {
                      handleInputChange(index, "customerName", value);
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        value={row.customerName}
                        onChange={(e) =>
                          handleInputChange(
                            index,
                            "customerName",
                            e.target.value
                          )
                        }
                        label="Customer Name"
                      />
                    )}
                  />
                </TableCell>
                <TableCell>
                  <TextField
                    type="number"
                    value={row.quantity}
                    onChange={(e) =>
                      handleInputChange(index, "quantity", e.target.value)
                    }
                    InputProps={{
                      inputProps: { style: { appearance: "textfield" } },
                    }}
                    sx={{
                      "& input[type=number]::-webkit-inner-spin-button": {
                        display: "none",
                      },
                      "& input[type=number]::-webkit-outer-spin-button": {
                        display: "none",
                      },
                    }}
                  />
                </TableCell>
                <TableCell>
                  <TextField
                    type="number"
                    value={row.weight}
                    onChange={(e) =>
                      handleInputChange(index, "weight", e.target.value)
                    }
                    InputProps={{
                      inputProps: { style: { appearance: "textfield" } },
                    }}
                    sx={{
                      "& input[type=number]::-webkit-inner-spin-button": {
                        display: "none",
                      },
                      "& input[type=number]::-webkit-outer-spin-button": {
                        display: "none",
                      },
                    }}
                  />
                </TableCell>
                <TableCell>
                  <TextField
                    type="number"
                    value={row.rate}
                    onChange={(e) =>
                      handleInputChange(index, "rate", e.target.value)
                    }
                    InputProps={{
                      inputProps: { style: { appearance: "textfield" } },
                    }}
                    sx={{
                      "& input[type=number]::-webkit-inner-spin-button": {
                        display: "none",
                      },
                      "& input[type=number]::-webkit-outer-spin-button": {
                        display: "none",
                      },
                    }}
                  />
                </TableCell>
                <TableCell>
                  <Typography>{row.payment.toFixed(2)}</Typography>
                </TableCell>
                <TableCell>
                  <Typography>{row.duePayment.toFixed(2)}</Typography>
                </TableCell>
                <TableCell>
                  <Typography>{row.totalPayment.toFixed(2)}</Typography>
                </TableCell>
                <TableCell>
                  <TextField
                    type="number"
                    value={row.creditPayment}
                    onChange={(e) =>
                      handleInputChange(index, "creditPayment", e.target.value)
                    }
                    InputProps={{
                      inputProps: { style: { appearance: "textfield" } },
                    }}
                    sx={{
                      "& input[type=number]::-webkit-inner-spin-button": {
                        display: "none",
                      },
                      "& input[type=number]::-webkit-outer-spin-button": {
                        display: "none",
                      },
                    }}
                  />
                </TableCell>
                <TableCell>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Typography sx={{ mr: 1 }}>
                      {row.totalDuePayment.toFixed(2)}
                    </Typography>
                    <IconButton
                      color="primary"
                      onClick={() =>
                        updateTotalDuePayment(
                          row.customerName,
                          row.totalDuePayment,
                          row
                        )
                      }
                    >
                      <CheckIcon />
                    </IconButton>
                  </Box>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
          <TableFooter>
            <TableRow>
              <TableCell>
                <Typography variant="h6">Totals</Typography>
              </TableCell>
              <TableCell>
                <Typography variant="h6">
                  {calculateTotal("quantity")}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography variant="h6">
                  {calculateTotal("weight").toFixed(2)}
                </Typography>
              </TableCell>
              <TableCell />
              <TableCell>
                <Typography variant="h6">
                  {calculateTotal("payment").toFixed(2)}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography variant="h6">
                  {calculateTotal("duePayment").toFixed(2)}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography variant="h6">
                  {calculateTotal("totalPayment").toFixed(2)}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography variant="h6">
                  {calculateTotal("creditPayment").toFixed(2)}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography variant="h6">
                  {calculateTotal("totalDuePayment").toFixed(2)}
                </Typography>
              </TableCell>
            </TableRow>
            <Box sx={{ display: "flex", justifyContent: "center", mt: 3 }}>
              <Button variant="contained" color="success" onClick={saveBill}>
                Save Bill
              </Button>
            </Box>
          </TableFooter>
        </Table>
      </TableContainer>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        pauseOnHover
        draggable
        theme="colored"
      />
    </Box>
  );
};

export default TodaysBills;
